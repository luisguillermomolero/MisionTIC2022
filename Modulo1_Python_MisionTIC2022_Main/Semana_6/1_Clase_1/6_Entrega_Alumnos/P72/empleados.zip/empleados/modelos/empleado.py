class Empleado:
    def __init__(self, nombre, documento, correo, especialidad):
        self.nombre = nombre
        self.documento = documento
        self.correo = correo
        self.especialidad = especialidad
