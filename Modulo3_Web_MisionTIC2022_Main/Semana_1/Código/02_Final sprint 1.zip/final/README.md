# workshop1
the code of the final excercise for the sprint1 misiotin2022

## The Project
This project was made for Daniel Duque to test the first workshop of the MisionTic2022 ciclo 3
> CICLO 3 DE FORMACIÓN: DESARROLLO DE SOFTWARE

This project starts with a `git` configuration using commands like
```
git add remote
git remote -v
git status
git add
git pull
git commit -m
git push
```

We are usinf the [GitHub Docs](https://docs.github.com/es/free-pro-team@latest/github/writing-on-github/basic-writing-and-formatting-syntax) to put this **README** in order